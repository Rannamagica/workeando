package com.microservicios.workenado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkenadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkenadoApplication.class, args);
	}

}
