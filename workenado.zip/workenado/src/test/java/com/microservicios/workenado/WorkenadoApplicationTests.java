package com.microservicios.workenado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkenadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
